package ro.yt.downloader

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import ro.yt.downloader.databinding.ActivityPlayerBinding

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val list = intent.getStringArrayExtra(EXTRA_URI_LIST)
        val single = intent.getStringExtra(EXTRA_URI)
        val uriStrings: Array<String> = when {
            !list.isNullOrEmpty() -> list
            !single.isNullOrEmpty() -> arrayOf(single)
            else -> {
                finish()
                return
            }
        }

        val exo = ExoPlayer.Builder(this).build()
        player = exo
        binding.playerView.player = exo
        exo.setMediaItems(uriStrings.map { MediaItem.fromUri(Uri.parse(it)) })
        exo.prepare()
        exo.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
        binding.playerView.player = null
    }

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_URI_LIST = "uri_list"
        const val EXTRA_TITLE = "title"
        const val EXTRA_MIME = "mime"
    }
}
