package ro.yt.downloader

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import java.io.File
import androidx.core.app.ShareCompat

object DownloadFileActions {

    fun openPlayerInApp(activity: Activity, entry: DownloadedFileEntry) {
        openPlayerPlaylist(activity, listOf(entry))
    }

    /** Redare ExoPlayer: unul sau mai mulți itemi ca playlist (ordinea din listă). */
    fun openPlayerPlaylist(activity: Activity, entries: List<DownloadedFileEntry>) {
        if (entries.isEmpty()) return
        try {
            val uris = entries.map { it.playUri(activity).toString() }.toTypedArray()
            activity.startActivity(
                Intent(activity, PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_URI_LIST, uris)
                }
            )
        } catch (e: Exception) {
            Toast.makeText(
                activity,
                "Nu pot reda: ${e.message ?: "eroare"}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /** LibVLC livrat în APK (nu cere instalarea aplicației VLC din magazin). */
    fun openVlcIntegrated(activity: Activity, entry: DownloadedFileEntry) {
        try {
            val uriStr = vlcPlayUriString(activity, entry)
            activity.startActivity(
                Intent(activity, VlcPlayerActivity::class.java).apply {
                    putExtra(VlcPlayerActivity.EXTRA_URI, uriStr)
                    putExtra(VlcPlayerActivity.EXTRA_TITLE, entry.title)
                }
            )
        } catch (e: Exception) {
            Toast.makeText(
                activity,
                "VLC integrat: ${e.message ?: "eroare"}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * LibVLC gestionează prost `content://` FileProvider; folosim calea reală dacă o avem.
     */
    private fun vlcPlayUriString(activity: Activity, entry: DownloadedFileEntry): String {
        entry.file?.takeIf { it.isFile && it.canRead() }?.let {
            return Uri.fromFile(it).toString()
        }
        val pub = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "YTDownloader/${entry.title}"
        )
        if (pub.isFile && pub.canRead()) {
            return Uri.fromFile(pub).toString()
        }
        return entry.playUri(activity).toString()
    }

    fun openPlayerExternal(activity: Activity, entry: DownloadedFileEntry) {
        try {
            val uri = entry.playUri(activity)
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, entry.mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(Intent.createChooser(view, "Redă cu"))
        } catch (_: Exception) {
            Toast.makeText(
                activity,
                "Nu s-a găsit o aplicație pentru redare.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun share(activity: Activity, entry: DownloadedFileEntry) {
        try {
            val uri = entry.playUri(activity)
            val mime = entry.mime.ifBlank { "*/*" }
            ShareCompat.IntentBuilder(activity)
                .setStream(uri)
                .setType(mime)
                .setChooserTitle("Trimite fișierul")
                .apply {
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    intent.clipData = ClipData.newUri(
                        activity.contentResolver,
                        entry.title,
                        uri
                    )
                }
                .startChooser()
        } catch (_: Exception) {
            Toast.makeText(activity, "Partaj eșuat.", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareMultiple(activity: Activity, entries: List<DownloadedFileEntry>) {
        if (entries.isEmpty()) return
        try {
            val uris = ArrayList(entries.map { it.playUri(activity) })
            val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newUri(
                    activity.contentResolver,
                    entries[0].title,
                    uris[0]
                ).also { cd ->
                    for (i in 1 until uris.size) {
                        cd.addItem(ClipData.Item(uris[i]))
                    }
                }
            }
            activity.startActivity(Intent.createChooser(send, "Trimite fișierele"))
        } catch (_: Exception) {
            Toast.makeText(activity, "Partaj eșuat.", Toast.LENGTH_SHORT).show()
        }
    }
}
