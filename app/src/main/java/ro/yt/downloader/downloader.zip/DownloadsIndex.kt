package ro.yt.downloader

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.util.Locale

object DownloadsIndex {

    private const val SUBFOLDER = "YTDownloader"

    /**
     * Toate fișierele din **Download/YTDownloader** (public): scanare directă pe disc + MediaStore
     * (Downloads + Files), cu deduplicare. Necesită permisiuni de citire pe Android 6+.
     */
    fun listPublicYtDownloaderOnly(context: Context): List<DownloadedFileEntry> {
        val byKey = LinkedHashMap<String, DownloadedFileEntry>()

        fun dedupeKey(name: String, size: Long) =
            "${name.lowercase(Locale.ROOT)}_$size"

        fun putMerged(key: String, entry: DownloadedFileEntry) {
            val existing = byKey[key]
            if (existing == null) {
                byKey[key] = entry
                return
            }
            if (existing.file == null && entry.file != null) {
                byKey[key] = entry
                return
            }
            if (existing.file != null && entry.file == null) {
                return
            }
            if (entry.sortKey > existing.sortKey) {
                byKey[key] = entry
            }
        }

        scanPublicFolderToMap(byKey, ::dedupeKey, ::putMerged)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            queryDownloadsCollection(context, byKey, ::dedupeKey, ::putMerged)
            queryFilesCollection(context, byKey, ::dedupeKey, ::putMerged)
        }

        return byKey.values.sortedByDescending { it.sortKey }
    }

    private fun scanPublicFolderToMap(
        byKey: MutableMap<String, DownloadedFileEntry>,
        dedupeKey: (String, Long) -> String,
        putMerged: (String, DownloadedFileEntry) -> Unit
    ) {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            SUBFOLDER
        )
        if (!dir.isDirectory) return
        dir.listFiles()?.forEach { f ->
            if (f.isFile && f.canRead() && f.length() > 0L) {
                val key = dedupeKey(f.name, f.length())
                putMerged(
                    key,
                    DownloadedFileEntry(
                        title = f.name,
                        mime = DownloadMime.guessFromFileName(f.name),
                        file = f,
                        contentUri = null,
                        sortKey = f.lastModified()
                    )
                )
            }
        }
    }

    private fun queryDownloadsCollection(
        context: Context,
        byKey: MutableMap<String, DownloadedFileEntry>,
        dedupeKey: (String, Long) -> String,
        putMerged: (String, DownloadedFileEntry) -> Unit
    ) {
        val resolver = context.contentResolver
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        val base = "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER"
        val baseLower = base.lowercase(Locale.ROOT)
        val selection = buildString {
            append("${MediaStore.MediaColumns.RELATIVE_PATH} = ? OR ")
            append("${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ")
            append("${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ")
            append("${MediaStore.MediaColumns.RELATIVE_PATH} = ? OR ")
            append("${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?")
        }
        val args = arrayOf(
            base,
            "$base/%",
            "%/$SUBFOLDER/%",
            baseLower,
            "$baseLower/%"
        )
        val sort = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        ingestMediaQuery(resolver, collection, projection, selection, args, sort, byKey, dedupeKey, putMerged)
    }

    private fun queryFilesCollection(
        context: Context,
        byKey: MutableMap<String, DownloadedFileEntry>,
        dedupeKey: (String, Long) -> String,
        putMerged: (String, DownloadedFileEntry) -> Unit
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        val base = "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER"
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR " +
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR " +
            "${MediaStore.MediaColumns.RELATIVE_PATH} = ? OR " +
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
        val args = arrayOf(
            "$base/%",
            "%/${SUBFOLDER}/%",
            base,
            "%/${SUBFOLDER.lowercase(Locale.ROOT)}/%"
        )
        val sort = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        ingestMediaQuery(resolver, collection, projection, selection, args, sort, byKey, dedupeKey, putMerged)
    }

    private fun ingestMediaQuery(
        resolver: android.content.ContentResolver,
        collection: Uri,
        projection: Array<String>,
        selection: String,
        args: Array<String>,
        sort: String,
        byKey: MutableMap<String, DownloadedFileEntry>,
        dedupeKey: (String, Long) -> String,
        putMerged: (String, DownloadedFileEntry) -> Unit
    ) {
        runCatching {
            resolver.query(collection, projection, selection, args, sort)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val iMod = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                val iPath = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val rel = c.getString(iPath) ?: continue
                    if (!isUnderYtDownloader(rel)) continue
                    val id = c.getLong(iId)
                    val name = c.getString(iName) ?: continue
                    val size = c.getLong(iSize)
                    val mime = c.getString(iMime) ?: DownloadMime.guessFromFileName(name)
                    val modSec = c.getLong(iMod)
                    val uri = ContentUris.withAppendedId(collection, id)
                    val key = dedupeKey(name, size)
                    putMerged(
                        key,
                        DownloadedFileEntry(
                            title = name,
                            mime = mime,
                            file = null,
                            contentUri = uri,
                            sortKey = modSec * 1000L
                        )
                    )
                }
            }
        }
    }

    private fun isUnderYtDownloader(relativePath: String): Boolean {
        val n = relativePath.trim().replace('\\', '/').lowercase(Locale.ROOT)
        val needle = "${Environment.DIRECTORY_DOWNLOADS.lowercase(Locale.ROOT)}/$SUBFOLDER".lowercase(Locale.ROOT)
        val needleLo = "${Environment.DIRECTORY_DOWNLOADS.lowercase(Locale.ROOT)}/${SUBFOLDER.lowercase(Locale.ROOT)}"
        return n == needle || n.startsWith("$needle/") || n.startsWith("$needleLo/")
    }

    fun listEntries(context: Context): List<DownloadedFileEntry> {
        val byKey = LinkedHashMap<String, DownloadedFileEntry>()

        fun putEntry(key: String, entry: DownloadedFileEntry) {
            if (!byKey.containsKey(key)) {
                byKey[key] = entry
            }
        }

        val privateDir = File(context.getExternalFilesDir(null), "downloads")
        privateDir.listFiles()
            ?.filter { it.isFile && it.length() > 0L }
            ?.sortedByDescending { it.lastModified() }
            ?.forEach { f ->
                val key = "${f.name}_${f.length()}"
                putEntry(
                    key,
                    DownloadedFileEntry(
                        title = f.name,
                        mime = DownloadMime.guessFromFileName(f.name),
                        file = f,
                        contentUri = null,
                        sortKey = f.lastModified()
                    )
                )
            }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            queryLegacyMediaStore(context, byKey)
        } else {
            val pub = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                SUBFOLDER
            )
            pub.listFiles()?.filter { it.isFile && it.length() > 0L }?.forEach { f ->
                val key = "${f.name}_${f.length()}"
                putEntry(
                    key,
                    DownloadedFileEntry(
                        title = f.name,
                        mime = DownloadMime.guessFromFileName(f.name),
                        file = f,
                        contentUri = null,
                        sortKey = f.lastModified()
                    )
                )
            }
        }

        return byKey.values.sortedByDescending { it.sortKey }
    }

    private fun queryLegacyMediaStore(
        context: Context,
        byKey: MutableMap<String, DownloadedFileEntry>
    ) {
        val basePath = "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER"
        val resolver = context.contentResolver
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ? OR " +
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
        val args = arrayOf(basePath, "$basePath/%")
        val sort = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        resolver.query(collection, projection, selection, args, sort)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iMod = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val name = c.getString(iName) ?: continue
                val size = c.getLong(iSize)
                val mime = c.getString(iMime) ?: DownloadMime.guessFromFileName(name)
                val modSec = c.getLong(iMod)
                val uri = ContentUris.withAppendedId(collection, id)
                val key = "${name}_$size"
                if (!byKey.containsKey(key)) {
                    byKey[key] = DownloadedFileEntry(
                        title = name,
                        mime = mime,
                        file = null,
                        contentUri = uri,
                        sortKey = modSec * 1000L
                    )
                }
            }
        }
    }
}
