package ro.yt.downloader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import java.io.File
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaStatus
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastStateListener
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import androidx.mediarouter.app.MediaRouteChooserDialog
import androidx.mediarouter.media.MediaRouteSelector

class PublicDownloadsActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var inputFilter: EditText
    private lateinit var emptyView: TextView
    private lateinit var recycler: RecyclerView
    private lateinit var selectionBar: View
    private lateinit var selectionCountLabel: TextView
    private lateinit var btnSelectionPlay: ImageButton
    private lateinit var btnSelectionShare: ImageButton
    private lateinit var btnSelectionCast: ImageButton

    private var allEntries: List<DownloadedFileEntry> = emptyList()
    private val selectedKeys = linkedSetOf<String>()

    private var castContext: CastContext? = null
    private var pendingCast: PendingCast? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingLoadRunnable: Runnable? = null
    private var wifiLock: WifiManager.WifiLock? = null

    /** Invalidează stop()/load() vechi când utilizatorul pornește o proiecție nouă (evită crash/race). */
    private var castOpToken = 0
    private var lastLoggedCastState: String? = null

    private data class PendingCast(val url: String, val mime: String, val title: String, val opToken: Int)

    private data class CastPlaylistState(
        val entries: List<DownloadedFileEntry>,
        var index: Int = 0,
        val opToken: Int
    )

    private var castPlaylist: CastPlaylistState? = null
    private var castMediaCallback: RemoteMediaClient.Callback? = null

    private val castStateListener = CastStateListener { invalidateOptionsMenu() }

    private val storagePermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        reloadFromDisk()
    }

    private val castSessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            acquireWifiHighPerf()
            ensureCastCallbackRegistered()
            pendingCast?.let { p ->
                scheduleLoadCast(p)
                pendingCast = null
            }
        }

        override fun onSessionStartFailed(session: CastSession, error: Int) {
            castOpToken++
            pendingCast = null
            castPlaylist = null
            LocalStreamHolder.stop()
            Toast.makeText(
                this@PublicDownloadsActivity,
                "Conectare Cast eșuată (cod $error).",
                Toast.LENGTH_LONG
            ).show()
        }

        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionEnded(session: CastSession, error: Int) {
            castOpToken++
            lastLoggedCastState = null
            castPlaylist = null
            unregisterCastMediaCallback()
            LocalStreamHolder.stop()
            releaseWifiHighPerf()
            invalidateOptionsMenu()
        }

        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            ensureCastCallbackRegistered()
            pendingCast?.let { p ->
                scheduleLoadCast(p)
                pendingCast = null
            }
        }

        override fun onSessionResumeFailed(session: CastSession, error: Int) {
            castOpToken++
            pendingCast = null
            castPlaylist = null
            LocalStreamHolder.stop()
        }

        override fun onSessionSuspended(session: CastSession, reason: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_public_downloads)
        toolbar = findViewById(R.id.toolbarPublicDownloads)
        inputFilter = findViewById(R.id.inputPublicFilter)
        emptyView = findViewById(R.id.publicDownloadsEmpty)
        recycler = findViewById(R.id.recyclerPublicDownloads)
        selectionBar = findViewById(R.id.selectionActionBar)
        selectionCountLabel = findViewById(R.id.selectionCountLabel)
        btnSelectionPlay = findViewById(R.id.btnSelectionPlay)
        btnSelectionShare = findViewById(R.id.btnSelectionShare)
        btnSelectionCast = findViewById(R.id.btnSelectionCast)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        castContext = runCatching { CastContext.getSharedInstance(this) }.getOrNull()
        if (castContext == null) {
            btnSelectionCast.visibility = View.GONE
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = PublicRowAdapter()

        btnSelectionPlay.setOnClickListener {
            val list = selectedEntriesInListOrder()
            if (list.isNotEmpty()) DownloadFileActions.openPlayerPlaylist(this, list)
        }
        btnSelectionShare.setOnClickListener {
            val list = selectedEntriesInListOrder()
            if (list.isNotEmpty()) DownloadFileActions.shareMultiple(this, list)
        }
        btnSelectionCast.setOnClickListener {
            val list = selectedEntriesInListOrder()
            if (list.isNotEmpty()) startCastPlaylist(list)
        }

        inputFilter.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })

        ensureStoragePermissionsThenLoad()
        consumeLaunchCastIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            consumeLaunchCastIntent(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_public_downloads, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val connected = castContext?.sessionManager?.currentCastSession?.isConnected == true
        menu.findItem(R.id.action_disconnect_cast)?.isVisible = connected
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_disconnect_cast) {
            disconnectCast()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onStart() {
        super.onStart()
        castContext?.addCastStateListener(castStateListener)
        castContext?.sessionManager?.addSessionManagerListener(
            castSessionListener,
            CastSession::class.java
        )
    }

    override fun onStop() {
        castContext?.removeCastStateListener(castStateListener)
        castContext?.sessionManager?.removeSessionManagerListener(
            castSessionListener,
            CastSession::class.java
        )
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (castContext?.sessionManager?.currentCastSession?.remoteMediaClient != null) {
            ensureCastCallbackRegistered()
        }
        if (hasStorageReadPermission()) {
            reloadFromDisk()
        }
        invalidateOptionsMenu()
    }

    override fun onDestroy() {
        pendingLoadRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingLoadRunnable = null
        unregisterCastMediaCallback()
        super.onDestroy()
    }

    private fun selectedEntriesInListOrder(): List<DownloadedFileEntry> {
        if (selectedKeys.isEmpty()) return emptyList()
        val set = selectedKeys.toSet()
        return allEntries.filter { it.stableKey() in set }
    }

    private fun updateSelectionUi() {
        val n = selectedKeys.size
        selectionBar.visibility = if (n > 0) View.VISIBLE else View.GONE
        selectionCountLabel.text = when (n) {
            0 -> ""
            1 -> "1 selectat"
            else -> "$n selectate"
        }
        val padBottom = if (n > 0) (88 * resources.displayMetrics.density).toInt() else 0
        recycler.setPadding(0, 0, 0, padBottom)
    }

    private fun toggleSelectionKey(key: String) {
        if (key in selectedKeys) selectedKeys.remove(key) else selectedKeys.add(key)
        updateSelectionUi()
        (recycler.adapter as? PublicRowAdapter)?.notifyDataSetChanged()
    }

    private fun isCastUiSafe(): Boolean =
        !isFinishing && (Build.VERSION.SDK_INT < 17 || !isDestroyed)

    private fun logCastStatusIfChanged() {
        if (!isCastUiSafe()) return
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient ?: return
        val st = client.mediaStatus ?: return
        val line =
            "CastStatus playerState=${st.playerState} idleReason=${st.idleReason} streamPos=${st.streamPosition}ms"
        if (line == lastLoggedCastState) return
        lastLoggedCastState = line
        DebugFileLog.append(this, "cast_debug.log", line)
        if (st.playerState == MediaStatus.PLAYER_STATE_IDLE &&
            st.idleReason == MediaStatus.IDLE_REASON_ERROR
        ) {
            DebugFileLog.append(
                this,
                "cast_debug.log",
                "Cast IDLE_ERROR: receiverul nu a putut reda fluxul (codec/container sau URL inaccesibil de pe TV)."
            )
        }
    }

    private fun ensureCastCallbackRegistered() {
        if (castMediaCallback != null) return
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient ?: return
        val cb = object : RemoteMediaClient.Callback() {
            override fun onStatusUpdated() {
                logCastStatusIfChanged()
                onCastMediaStatusUpdated()
            }
        }
        castMediaCallback = cb
        client.registerCallback(cb)
    }

    private fun unregisterCastMediaCallback() {
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient
        val cb = castMediaCallback ?: return
        runCatching { client?.unregisterCallback(cb) }
        castMediaCallback = null
    }

    private fun onCastMediaStatusUpdated() {
        val pl = castPlaylist ?: return
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient ?: return
        val status = client.mediaStatus ?: return
        if (status.playerState != MediaStatus.PLAYER_STATE_IDLE) return
        if (status.idleReason != MediaStatus.IDLE_REASON_FINISHED) return
        val next = pl.index + 1
        if (next >= pl.entries.size) {
            castPlaylist = null
            if (pl.entries.size > 1) {
                runOnUiThread {
                    Toast.makeText(
                        this@PublicDownloadsActivity,
                        "Proiecție: playlist încheiat.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            return
        }
        pl.index = next
        val entry = pl.entries[next]
        runOnUiThread {
            loadCastForConnectedSession(entry)
        }
    }

    private fun hasStorageReadPermission(): Boolean {
        return when {
            Build.VERSION.SDK_INT >= 33 -> {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.READ_MEDIA_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
            else -> true
        }
    }

    private fun ensureStoragePermissionsThenLoad() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                need.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_MEDIA_AUDIO
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                need.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        if (need.isEmpty()) {
            reloadFromDisk()
        } else {
            storagePermLauncher.launch(need.toTypedArray())
        }
    }

    private fun acquireWifiHighPerf() {
        if (wifiLock?.isHeld == true) return
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as? WifiManager ?: return
        @Suppress("DEPRECATION")
        wifiLock = wm.createWifiLock(
            WifiManager.WIFI_MODE_FULL_HIGH_PERF,
            "ro.yt.downloader.cast"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWifiHighPerf() {
        wifiLock?.takeIf { it.isHeld }?.release()
        wifiLock = null
    }

    private fun disconnectCast() {
        castOpToken++
        lastLoggedCastState = null
        pendingCast = null
        castPlaylist = null
        pendingLoadRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingLoadRunnable = null
        LocalStreamHolder.stop()
        unregisterCastMediaCallback()
        val sm = castContext?.sessionManager
        runCatching {
            sm?.currentCastSession?.remoteMediaClient?.stop()
        }
        runCatching {
            sm?.endCurrentSession(true)
        }
        releaseWifiHighPerf()
        invalidateOptionsMenu()
        Toast.makeText(this, "Proiectarea a fost închisă.", Toast.LENGTH_LONG).show()
    }

    private fun reloadFromDisk() {
        Thread {
            val list = DownloadsIndex.listPublicYtDownloaderOnly(this)
            runOnUiThread {
                allEntries = list
                selectedKeys.clear()
                updateSelectionUi()
                applyFilter()
            }
        }.start()
    }

    /** Din VLC: pornește proiecția pentru calea primită, fără să revii la MainActivity. */
    private fun consumeLaunchCastIntent(i: Intent?) {
        val path = i?.getStringExtra(EXTRA_LAUNCH_CAST_FILE) ?: return
        i.removeExtra(EXTRA_LAUNCH_CAST_FILE)
        val f = File(path)
        if (!f.isFile) return
        val mime = DownloadMime.guessFromFileName(f.name)
        val entry = DownloadedFileEntry(
            title = f.name,
            mime = mime,
            file = f,
            contentUri = null,
            sortKey = f.lastModified()
        )
        mainHandler.postDelayed({
            if (!isCastUiSafe()) return@postDelayed
            startCastPlaylist(listOf(entry))
        }, 500L)
    }

    private fun applyFilter() {
        val q = inputFilter.text.toString().trim().lowercase()
        val filtered = if (q.isEmpty()) {
            allEntries
        } else {
            allEntries.filter { it.title.lowercase().contains(q) }
        }
        (recycler.adapter as? PublicRowAdapter)?.submit(filtered)
        when {
            allEntries.isEmpty() -> {
                emptyView.visibility = View.VISIBLE
                emptyView.text =
                    if (!hasStorageReadPermission()) {
                        "Acordă permisiunea de citire (video/audio) ca să vezi toate fișierele din folder."
                    } else {
                        "Nu s-au găsit fișiere în Download/YTDownloader."
                    }
            }
            filtered.isEmpty() -> {
                emptyView.visibility = View.VISIBLE
                emptyView.text = "Nicio potrivire pentru „$q”."
            }
            else -> emptyView.visibility = View.GONE
        }
    }

    private fun showFileMenu(entry: DownloadedFileEntry, anchor: View) {
        val popup = PopupMenu(this, anchor, Gravity.END)
        popup.menuInflater.inflate(R.menu.menu_download_file, popup.menu)
        forcePopupMenuIcons(popup)
        if (castContext == null) {
            popup.menu.findItem(R.id.action_cast_file)?.isVisible = false
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_play_file -> {
                    DownloadFileActions.openPlayerInApp(this, entry)
                    true
                }
                R.id.action_vlc_integrated -> {
                    DownloadFileActions.openVlcIntegrated(this, entry)
                    true
                }
                R.id.action_share_file -> {
                    DownloadFileActions.share(this, entry)
                    true
                }
                R.id.action_cast_file -> {
                    startCastPlaylist(listOf(entry))
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun forcePopupMenuIcons(popup: PopupMenu) {
        try {
            val f = PopupMenu::class.java.getDeclaredField("mPopup")
            f.isAccessible = true
            val helper = f.get(popup) ?: return
            val m = helper.javaClass.getMethod("setForceShowIcon", Boolean::class.javaPrimitiveType)
            m.invoke(helper, true)
        } catch (_: Exception) {
        }
    }

    private fun showCastDevicePicker() {
        val selector = MediaRouteSelector.Builder()
            .addControlCategory(
                CastMediaControlIntent.categoryForCast(
                    CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID
                )
            )
            .build()
        val dialog = MediaRouteChooserDialog(this)
        dialog.setRouteSelector(selector)
        dialog.show()
    }

    private fun pendingCastForEntry(entry: DownloadedFileEntry, opToken: Int): PendingCast? {
        val streamMime = if (entry.file != null) {
            val mr = CastMimeHelper.forFile(entry.file)
            if (!mr.supported && mr.hint != null) {
                mainHandler.post {
                    if (isCastUiSafe() && opToken == castOpToken) {
                        Toast.makeText(this@PublicDownloadsActivity, mr.hint, Toast.LENGTH_LONG).show()
                    }
                }
            }
            DownloadMime.normalizeForCast(mr.mime, entry.title)
        } else {
            DownloadMime.normalizeForCast(entry.mime, entry.title)
        }
        val url = LocalStreamHolder.start(this, entry.file, entry.contentUri, streamMime) ?: return null
        return PendingCast(url, streamMime, entry.title, opToken)
    }

    private fun safeStopThenLoad(client: RemoteMediaClient, pending: PendingCast) {
        val token = pending.opToken
        try {
            @Suppress("DEPRECATION")
            val stopped = client.stop()
            if (stopped != null) {
                stopped.setResultCallback {
                    mainHandler.post {
                        if (!isCastUiSafe() || token != castOpToken) return@post
                        scheduleLoadCast(pending)
                    }
                }
            } else {
                mainHandler.post {
                    if (!isCastUiSafe() || token != castOpToken) return@post
                    scheduleLoadCast(pending)
                }
            }
        } catch (e: Exception) {
            DebugFileLog.append(this, "cast_debug.log", "safeStopThenLoad: ${e.message}")
            mainHandler.postDelayed({
                if (isCastUiSafe() && token == castOpToken) scheduleLoadCast(pending)
            }, 350L)
        }
    }

    private fun startCastPlaylist(entries: List<DownloadedFileEntry>) {
        if (entries.isEmpty()) return
        if (castContext == null) {
            Toast.makeText(
                this,
                "Proiectarea necesită Google Play Services.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        castOpToken++
        val opToken = castOpToken
        lastLoggedCastState = null
        pendingLoadRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingLoadRunnable = null

        castPlaylist = CastPlaylistState(entries.toList(), 0, opToken)
        val p = pendingCastForEntry(entries[0], opToken) ?: run {
            Toast.makeText(
                this,
                "Nu pot porni serverul HTTP: fără IP Wi‑Fi util. Dezactivează VPN/Tailscale ca Chromecast să poată accesa telefonul.",
                Toast.LENGTH_LONG
            ).show()
            castPlaylist = null
            return
        }
        pendingCast = p
        val sm = castContext!!.sessionManager
        val client = sm.currentCastSession?.remoteMediaClient
        if (client != null) {
            val pending = pendingCast!!
            pendingCast = null
            ensureCastCallbackRegistered()
            safeStopThenLoad(client, pending)
        } else {
            Toast.makeText(
                this,
                "Alege televizorul / Chromecast din listă.",
                Toast.LENGTH_SHORT
            ).show()
            showCastDevicePicker()
        }
    }

    private fun loadCastForConnectedSession(entry: DownloadedFileEntry) {
        val pl = castPlaylist ?: return
        val opToken = pl.opToken
        val p = pendingCastForEntry(entry, opToken) ?: run {
            Toast.makeText(
                this,
                "Nu pot deschide următorul fișier pentru proiecție.",
                Toast.LENGTH_LONG
            ).show()
            castPlaylist = null
            return
        }
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient ?: run {
            castPlaylist = null
            return
        }
        ensureCastCallbackRegistered()
        DebugFileLog.append(
            this,
            "cast_debug.log",
            "playlist idx=${castPlaylist?.index} title=${entry.title} url=${p.url} mime=${p.mime}"
        )
        safeStopThenLoad(client, p)
    }

    private fun scheduleLoadCast(p: PendingCast) {
        pendingLoadRunnable?.let { mainHandler.removeCallbacks(it) }
        val token = p.opToken
        val r = Runnable {
            if (!isCastUiSafe() || token != castOpToken) return@Runnable
            loadCastMedia(p.url, p.mime, p.title, 0, token)
        }
        pendingLoadRunnable = r
        mainHandler.postDelayed(r, 900)
    }

    private fun loadCastMedia(url: String, mime: String, title: String, attempt: Int, opToken: Int) {
        if (opToken != castOpToken) return
        val session = castContext?.sessionManager?.currentCastSession
        val client = session?.remoteMediaClient
        if (client == null) {
            if (isCastUiSafe()) {
                Toast.makeText(this, "Sesiune Cast indisponibilă.", Toast.LENGTH_SHORT).show()
            }
            return
        }
        val castMime = DownloadMime.normalizeForCast(mime, title)
        val metaType =
            if (castMime.startsWith("audio")) MediaMetadata.MEDIA_TYPE_MUSIC_TRACK
            else MediaMetadata.MEDIA_TYPE_MOVIE
        val metadata = MediaMetadata(metaType).apply {
            putString(MediaMetadata.KEY_TITLE, title)
        }
        val mediaInfo = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setStreamDuration(-1L)
            .setContentType(castMime)
            .setMetadata(metadata)
            .build()
        val request = MediaLoadRequestData.Builder()
            .setMediaInfo(mediaInfo)
            .setAutoplay(true)
            .build()
        DebugFileLog.append(
            this,
            "cast_debug.log",
            "loadCast attempt=$attempt url=$url type=$castMime opToken=$opToken (preCheck HEAD…)"
        )
        Thread {
            val headOk = NetworkUtil.isHttpHeadOk(url)
            DebugFileLog.append(
                applicationContext,
                "cast_debug.log",
                "preCast HEAD url=$url ok=$headOk"
            )
            mainHandler.post {
                if (!isCastUiSafe() || opToken != castOpToken) return@post
                if (!headOk) {
                    Toast.makeText(
                        this,
                        "Verificare: URL-ul local nu răspunde la HEAD. TV-ul poate să nu primească stream-ul; verifică Wi‑Fi.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                executeCastLoad(client, request, url, castMime, title, attempt, opToken)
            }
        }.start()
    }

    private fun executeCastLoad(
        client: RemoteMediaClient,
        request: MediaLoadRequestData,
        url: String,
        castMime: String,
        title: String,
        attempt: Int,
        opToken: Int
    ) {
        try {
            @Suppress("DEPRECATION")
            client.load(request).setResultCallback { result ->
                mainHandler.post {
                    if (!isCastUiSafe() || opToken != castOpToken) return@post
                    DebugFileLog.append(
                        this,
                        "cast_debug.log",
                        "loadCast result success=${result.status.isSuccess} code=${result.status.statusCode} msg=${result.status.statusMessage}"
                    )
                    if (!result.status.isSuccess) {
                        if (attempt < 2) {
                            mainHandler.postDelayed(
                                { loadCastMedia(url, castMime, title, attempt + 1, opToken) },
                                1800L
                            )
                        } else {
                            Toast.makeText(
                                this,
                                "Cast nu a pornit redarea: ${result.status.statusMessage ?: result.status}",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        ensureCastCallbackRegistered()
                    }
                }
            }
        } catch (e: Exception) {
            DebugFileLog.append(this, "cast_debug.log", "loadCast exception: ${e.message}")
            if (attempt < 2 && isCastUiSafe()) {
                mainHandler.postDelayed(
                    { loadCastMedia(url, castMime, title, attempt + 1, opToken) },
                    1800L
                )
            }
        }
    }

    private inner class PublicRowAdapter : RecyclerView.Adapter<PublicRowAdapter.VH>() {

        private var items: List<DownloadedFileEntry> = emptyList()

        fun submit(list: List<DownloadedFileEntry>) {
            items = list
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_public_download_row, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(items[position])
        }

        inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val checkbox: CheckBox = itemView.findViewById(R.id.rowCheckbox)
            private val title: TextView = itemView.findViewById(R.id.rowFileTitle)
            private val more: ImageButton = itemView.findViewById(R.id.btnRowMore)

            fun bind(entry: DownloadedFileEntry) {
                val key = entry.stableKey()
                title.text = entry.title
                more.setOnClickListener { showFileMenu(entry, more) }

                checkbox.setOnCheckedChangeListener(null)
                checkbox.isChecked = key in selectedKeys
                checkbox.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) selectedKeys.add(key) else selectedKeys.remove(key)
                    updateSelectionUi()
                }
                title.setOnClickListener {
                    checkbox.isChecked = !checkbox.isChecked
                }
            }
        }
    }

    companion object {
        const val EXTRA_LAUNCH_CAST_FILE = "launch_cast_file"
    }
}
