package ro.yt.downloader

import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Toast
import com.google.android.gms.cast.framework.CastContext
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.Locale

/**
 * Redare integrată cu **LibVLC** + bară de control (play/pauză, derulare, volum).
 * **Proiectează** trimite la lista Descărcări care pornește Cast pentru același fișier.
 */
class VlcPlayerActivity : AppCompatActivity() {

    private var libVLC: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var loading: View
    private lateinit var topBar: View
    private lateinit var bottomControls: View
    private lateinit var btnBack: ImageButton
    private lateinit var btnCast: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var titleBar: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var volumeBar: SeekBar
    private lateinit var timeLabel: TextView

    private var mediaUri: Uri? = null
    private var titleText: String = ""

    private val mainHandler = Handler(Looper.getMainLooper())
    private var userDraggingSeek = false
    private var controlsVisible = true

    private val progressRunnable = object : Runnable {
        override fun run() {
            if (isFinishing || (Build.VERSION.SDK_INT >= 17 && isDestroyed)) return
            val mp = mediaPlayer ?: return
            val len = mp.length
            val t = mp.time
            if (len > 0 && !userDraggingSeek) {
                seekBar.max = len.toInt().coerceAtLeast(1)
                seekBar.progress = t.toInt().coerceIn(0, seekBar.max)
            }
            timeLabel.text = "${formatMs(t)} / ${formatMs(len)}"
            if (mp.isPlaying) {
                mainHandler.postDelayed(this, 400L)
            }
        }
    }

    private fun log(msg: String) {
        DebugFileLog.append(this, "vlc_debug.log", msg)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        log("onCreate")
        setContentView(R.layout.activity_vlc_player)
        videoLayout = findViewById(R.id.vlcVideoLayout)
        loading = findViewById(R.id.vlcLoading)
        topBar = findViewById(R.id.vlcTopBar)
        bottomControls = findViewById(R.id.vlcBottomControls)
        btnBack = findViewById(R.id.vlcBtnBack)
        btnCast = findViewById(R.id.vlcBtnCast)
        btnPlayPause = findViewById(R.id.vlcBtnPlayPause)
        btnClose = findViewById(R.id.vlcBtnStopClose)
        titleBar = findViewById(R.id.vlcTitleBar)
        seekBar = findViewById(R.id.vlcSeekBar)
        volumeBar = findViewById(R.id.vlcVolumeBar)
        timeLabel = findViewById(R.id.vlcTimeLabel)

        val uriStr = intent.getStringExtra(EXTRA_URI) ?: run {
            log("EXTRA_URI missing — finish")
            finish()
            return
        }
        titleText = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        titleBar.text = titleText.ifBlank { "Redare" }
        mediaUri = resolveForVlc(Uri.parse(uriStr))
        log("uriIn=$uriStr resolved=${mediaUri} scheme=${mediaUri?.scheme}")

        if (runCatching { CastContext.getSharedInstance(this) }.getOrNull() == null) {
            btnCast.visibility = View.GONE
        }

        btnBack.setOnClickListener { finish() }
        btnClose.setOnClickListener { finish() }
        btnCast.setOnClickListener { launchCastForCurrentFile() }
        btnPlayPause.setOnClickListener { togglePlayPause() }

        videoLayout.setOnClickListener { toggleChromeVisibility() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val mp = mediaPlayer ?: return
                    val len = mp.length
                    if (len > 0) {
                        timeLabel.text = "${formatMs(progress.toLong())} / ${formatMs(len)}"
                    }
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                userDraggingSeek = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                userDraggingSeek = false
                mediaPlayer?.let { mp ->
                    val len = mp.length
                    if (len > 0) {
                        mp.time = seekBar.progress.toLong().coerceIn(0, len)
                    }
                }
            }
        })

        volumeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    runCatching { mediaPlayer?.setVolume(progress) }
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        updatePlayPauseIcon()
    }

    private fun toggleChromeVisibility() {
        controlsVisible = !controlsVisible
        val v = if (controlsVisible) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomControls.visibility = v
    }

    private fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        if (mp.isPlaying) {
            mp.pause()
        } else {
            mp.play()
        }
        updatePlayPauseIcon()
        scheduleProgressUpdates()
    }

    private fun updatePlayPauseIcon() {
        val playing = mediaPlayer?.isPlaying == true
        btnPlayPause.setImageResource(
            if (playing) R.drawable.ic_action_pause else R.drawable.ic_action_play
        )
    }

    private fun scheduleProgressUpdates() {
        mainHandler.removeCallbacks(progressRunnable)
        if (mediaPlayer?.isPlaying == true) {
            mainHandler.post(progressRunnable)
        }
    }

    private fun launchCastForCurrentFile() {
        val u = mediaUri ?: return
        val path = u.path ?: run {
            Toast.makeText(this, "Proiectează: cale fișier indisponibilă.", Toast.LENGTH_LONG).show()
            return
        }
        val file = File(path)
        if (!file.isFile) {
            Toast.makeText(
                this,
                "Proiectează: deschide din lista Descărcări sau folosește un fișier local.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        startActivity(
            Intent(this, PublicDownloadsActivity::class.java).apply {
                putExtra(PublicDownloadsActivity.EXTRA_LAUNCH_CAST_FILE, file.absolutePath)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
        )
    }

    private fun formatMs(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val s = ms / 1000L
        val m = s / 60L
        val h = m / 60L
        return if (h > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", h, m % 60L, s % 60L)
        } else {
            String.format(Locale.US, "%d:%02d", m, s % 60L)
        }
    }

    private fun resolveForVlc(uri: Uri): Uri {
        if ("file".equals(uri.scheme, ignoreCase = true)) return uri
        if (!"content".equals(uri.scheme, ignoreCase = true)) return uri
        val segs = uri.pathSegments
        if (segs.isEmpty()) return uri
        val name = segs.last()
        val looksYt = segs.any { it.contains("ytdownloader", ignoreCase = true) } ||
            uri.authority?.contains("fileprovider", ignoreCase = true) == true
        if (!looksYt) return uri
        val f = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "YTDownloader/$name"
        )
        return if (f.isFile && f.canRead()) {
            Uri.fromFile(f)
        } else {
            uri
        }
    }

    override fun onStart() {
        super.onStart()
        log("onStart mediaPlayerNull=${mediaPlayer == null}")
        if (mediaPlayer != null) return
        val uri = mediaUri ?: return
        videoLayout.post {
            log("post bindAndPlay")
            bindAndPlay(uri)
        }
    }

    private fun bindAndPlay(uri: Uri) {
        if (isFinishing || mediaPlayer != null) {
            log("bindAndPlay skip finishing=$isFinishing hasPlayer=${mediaPlayer != null}")
            return
        }
        val options = ArrayList<String>().apply {
            add("--network-caching=2000")
            add("--file-caching=2000")
        }
        val vlc = LibVLC(this, options)
        libVLC = vlc
        val player = MediaPlayer(vlc)
        mediaPlayer = player
        log("LibVLC + MediaPlayer created")

        player.setEventListener(MediaPlayer.EventListener { event ->
            val typeName = event.typeName()
            log("event type=$typeName (${event.type})")
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Opening -> loading.visibility = View.VISIBLE
                    MediaPlayer.Event.Playing -> {
                        loading.visibility = View.GONE
                        updatePlayPauseIcon()
                        scheduleProgressUpdates()
                    }
                    MediaPlayer.Event.Buffering -> loading.visibility = View.VISIBLE
                    MediaPlayer.Event.Paused -> {
                        loading.visibility = View.GONE
                        updatePlayPauseIcon()
                        mainHandler.removeCallbacks(progressRunnable)
                        progressRunnable.run()
                    }
                    MediaPlayer.Event.Stopped -> {
                        loading.visibility = View.GONE
                        updatePlayPauseIcon()
                        mainHandler.removeCallbacks(progressRunnable)
                    }
                    MediaPlayer.Event.EndReached -> {
                        log("EndReached — reset la început")
                        loading.visibility = View.GONE
                        runCatching {
                            player.pause()
                            player.time = 0L
                        }
                        updatePlayPauseIcon()
                        mainHandler.removeCallbacks(progressRunnable)
                        progressRunnable.run()
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        log("EncounteredError")
                        loading.visibility = View.GONE
                    }
                    else -> {}
                }
            }
        })

        try {
            player.attachViews(videoLayout, null, false, false)
            log("attachViews OK")
        } catch (e: Exception) {
            log("attachViews FAIL: ${e.message}")
        }

        val media = if ("file".equals(uri.scheme, ignoreCase = true)) {
            val p = uri.path
            if (p.isNullOrEmpty()) {
                log("file URI fără path")
                Media(vlc, uri).apply { setHWDecoderEnabled(false, false) }
            } else {
                Media(vlc, p).apply { setHWDecoderEnabled(false, false) }
            }
        } else {
            Media(vlc, uri).apply { setHWDecoderEnabled(false, false) }
        }
        player.media = media
        media.release()
        try {
            player.play()
            runCatching {
                volumeBar.progress = player.volume.coerceIn(0, volumeBar.max)
            }
            log("play() called")
        } catch (e: Exception) {
            log("play() FAIL: ${e.message}")
        }
    }

    private fun MediaPlayer.Event.typeName(): String =
        when (type) {
            MediaPlayer.Event.Opening -> "Opening"
            MediaPlayer.Event.Buffering -> "Buffering"
            MediaPlayer.Event.Playing -> "Playing"
            MediaPlayer.Event.Paused -> "Paused"
            MediaPlayer.Event.Stopped -> "Stopped"
            MediaPlayer.Event.EndReached -> "EndReached"
            MediaPlayer.Event.EncounteredError -> "EncounteredError"
            MediaPlayer.Event.TimeChanged -> "TimeChanged"
            MediaPlayer.Event.PositionChanged -> "PositionChanged"
            MediaPlayer.Event.Vout -> "Vout"
            MediaPlayer.Event.ESAdded -> "ESAdded"
            MediaPlayer.Event.ESDeleted -> "ESDeleted"
            else -> "Other"
        }

    override fun onStop() {
        log("onStop releasePlayer")
        mainHandler.removeCallbacks(progressRunnable)
        releasePlayer()
        super.onStop()
    }

    private fun releasePlayer() {
        mediaPlayer?.stop()
        mediaPlayer?.detachViews()
        mediaPlayer?.release()
        mediaPlayer = null
        libVLC?.release()
        libVLC = null
    }

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
    }
}
