package ro.yt.downloader

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Collections

object NetworkUtil {

    /**
     * IPv4 folosită în URL-ul HTTP servit pentru Chromecast.
     * Evită **100.64.0.0/10** (CGNAT / Tailscale / VPN overlay): Chromecast-ul de pe Wi‑Fi
     * nu poate accesa aceste adrese chiar dacă `Cast.load()` raportează succes pe telefon.
     */
    fun localIpv4(context: Context): String? {
        val all = linkedSetOf<Inet4Address>()
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE)
            as? ConnectivityManager ?: return pickBest(fallbackFromInterfaces())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (network in cm.allNetworks) {
                val link = cm.getLinkProperties(network) ?: continue
                for (la in link.linkAddresses) {
                    val a = la.address
                    if (!a.isLoopbackAddress && a is Inet4Address) {
                        all.add(a)
                    }
                }
            }
        }
        if (all.isEmpty()) {
            all.addAll(fallbackFromInterfaces())
        }
        return pickBest(all.toList())
    }

    private fun fallbackFromInterfaces(): List<Inet4Address> {
        val out = mutableListOf<Inet4Address>()
        try {
            Collections.list(java.net.NetworkInterface.getNetworkInterfaces()).forEach { ni ->
                Collections.list(ni.inetAddresses).forEach { addr ->
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        out.add(addr)
                    }
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** 100.64.0.0/10 — RFC 6598, folosit des de VPN (ex. Tailscale); nu e LAN-ul Wi‑Fi. */
    private fun isCgnatOrVpnOverlay(ip: Inet4Address): Boolean {
        val b = ip.address
        if (b.size < 4) return false
        val o1 = b[0].toInt() and 0xff
        val o2 = b[1].toInt() and 0xff
        return o1 == 100 && o2 in 64..127
    }

    private fun isPrivateLan(ip: Inet4Address): Boolean {
        val b = ip.address
        if (b.size < 4) return false
        val o1 = b[0].toInt() and 0xff
        val o2 = b[1].toInt() and 0xff
        if (o1 == 10) return true
        if (o1 == 172 && o2 in 16..31) return true
        if (o1 == 192 && o2 == 168) return true
        return false
    }

    private fun pickBest(candidates: List<Inet4Address>): String? {
        if (candidates.isEmpty()) return null
        val noOverlay = candidates.filter { !isCgnatOrVpnOverlay(it) }
        if (noOverlay.isEmpty()) return null
        noOverlay.filter { isPrivateLan(it) }.firstOrNull()?.hostAddress?.let { return it }
        return noOverlay.firstOrNull()?.hostAddress
    }

    /** Verificare TCP; nu apela pe main thread dacă timeout mare. */
    fun isTcpPortOpen(host: String, port: Int, timeoutMs: Int = 1500): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * HEAD simplu (fără Range) — dacă eșuează de pe telefon, Chromecast poate avea aceeași problemă.
     */
    fun isHttpHeadOk(url: String, timeoutMs: Int = 2500): Boolean {
        return try {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                instanceFollowRedirects = false
            }
            val code = c.responseCode
            c.disconnect()
            code in 200..299
        } catch (_: Exception) {
            false
        }
    }
}
