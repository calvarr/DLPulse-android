package ro.yt.downloader

import android.content.Context
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Încearcă Download/YTDownloader; dacă scrierea eșuează (scoped storage),
 * folosește directorul logs din spațiul privat al aplicației.
 */
object DebugFileLog {

    private val lock = Any()
    private val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    fun append(context: Context, fileName: String, message: String) {
        synchronized(lock) {
            val line = "${timeFmt.format(Date())} $message\n"
            val pub = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "YTDownloader"
            ).resolve(fileName)
            if (!tryWrite(pub, line)) {
                val dir = context.getExternalFilesDir("logs")
                    ?: File(context.filesDir, "logs").also { it.mkdirs() }
                tryWrite(File(dir, fileName), line)
            }
        }
    }

    private fun tryWrite(file: File, line: String): Boolean =
        runCatching {
            file.parentFile?.mkdirs()
            if (!file.exists()) file.createNewFile()
            file.appendText(line)
            true
        }.getOrDefault(false)
}
