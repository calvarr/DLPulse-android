package ro.yt.downloader

/**
 * Mesajele yt-dlp includ adesea multe WARNING-uri; pentru UI păstrăm liniile utile.
 */
object YtdlpError {

    fun sanitizeForUser(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return "Eroare necunoscută."
        val errorLines = text.lines()
            .map { it.trim() }
            .filter { it.startsWith("ERROR", ignoreCase = true) }
        val base = if (errorLines.isNotEmpty()) {
            errorLines.joinToString("\n").take(600)
        } else {
            val noWarnings = text.lines()
                .filterNot { it.trimStart().startsWith("WARNING", ignoreCase = true) }
                .joinToString("\n")
                .trim()
            (if (noWarnings.isNotBlank()) noWarnings else text).take(600)
        }
        return appendNetworkHint(base)
    }

    private fun appendNetworkHint(msg: String): String {
        val m = msg.lowercase()
        if ("errno 7" in m || "no address associated" in m || "name or service not known" in m) {
            return msg + "\n\n— Rețea/DNS: verifică Wi‑Fi sau date mobile, încearcă fără VPN sau alt DNS."
        }
        return msg
    }
}
