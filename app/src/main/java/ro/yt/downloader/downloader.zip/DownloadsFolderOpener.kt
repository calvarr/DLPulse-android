package ro.yt.downloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.widget.Toast

object DownloadsFolderOpener {

    private const val SUBFOLDER = "YTDownloader"

    /**
     * Încearcă să deschidă folderul public **Download/YTDownloader** în managerul de fișiere.
     */
    fun openYtDownloaderFolder(context: Context) {
        val intents = mutableListOf<Intent>()

        val docUri = Uri.parse(
            "content://com.android.externalstorage.documents/document/primary%3A" +
                Environment.DIRECTORY_DOWNLOADS + "%2F" + SUBFOLDER
        )
        intents.add(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(docUri, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        )

        intents.add(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(
                    Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"),
                    DocumentsContract.Document.MIME_TYPE_DIR
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        )

        intents.add(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))

        for (intent in intents) {
            try {
                context.startActivity(Intent.createChooser(intent, "Deschide folderul"))
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(
            context,
            "Deschide manual: Descărcări → $SUBFOLDER",
            Toast.LENGTH_LONG
        ).show()
    }
}
