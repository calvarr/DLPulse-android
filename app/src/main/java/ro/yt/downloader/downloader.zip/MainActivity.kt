package ro.yt.downloader

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ScrollView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var inputUrl: EditText
    private lateinit var btnGo: Button
    private lateinit var statusText: TextView
    private lateinit var errorText: TextView
    private lateinit var urlOptionsRow: LinearLayout
    private lateinit var switchNoPlaylist: SwitchCompat
    private lateinit var searchPanel: LinearLayout
    private lateinit var searchRecycler: RecyclerView
    private lateinit var cbSelectAll: CheckBox
    private lateinit var btnDownloadBatch: Button
    private lateinit var playlistPanel: LinearLayout
    private lateinit var playlistRecycler: RecyclerView
    private lateinit var cbPlaylistSelectAll: CheckBox
    private lateinit var btnDownloadPlaylistSelected: Button
    private lateinit var btnDownloadPlaylistFull: Button
    private lateinit var formatSpinner: Spinner
    private lateinit var btnDownload: Button
    private lateinit var progressPrepare: ProgressBar
    private lateinit var downloadProgressContainer: LinearLayout
    private lateinit var downloadProgressBar: ProgressBar
    private lateinit var downloadProgressText: TextView

    private lateinit var savePrefs: SaveLocationPrefs
    private var searchAdapter: SearchResultsAdapter? = null
    private var playlistAdapter: SearchResultsAdapter? = null
    private var currentVideoUrl: String? = null
    private var pendingAfterFolder: Runnable? = null

    private lateinit var btnIconUpdate: ImageButton
    private lateinit var btnIconDonate: ImageButton
    private lateinit var btnIconFolder: ImageButton
    private lateinit var terminalOverlay: View
    private lateinit var terminalLog: TextView
    private lateinit var terminalScroll: ScrollView
    private lateinit var terminalProgress: ProgressBar
    private lateinit var btnTerminalClose: Button

    private val openTreeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: SecurityException) {
            }
            savePrefs.setTreeUri(uri)
            pendingAfterFolder?.run()
        }
        pendingAfterFolder = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        savePrefs = SaveLocationPrefs(this)

        inputUrl = findViewById(R.id.inputUrl)
        btnGo = findViewById(R.id.btnGo)
        statusText = findViewById(R.id.statusText)
        errorText = findViewById(R.id.errorText)
        urlOptionsRow = findViewById(R.id.urlOptionsRow)
        switchNoPlaylist = findViewById(R.id.switchNoPlaylist)
        searchPanel = findViewById(R.id.searchPanel)
        searchRecycler = findViewById(R.id.searchRecycler)
        cbSelectAll = findViewById(R.id.cbSelectAll)
        btnDownloadBatch = findViewById(R.id.btnDownloadBatch)
        playlistPanel = findViewById(R.id.playlistPanel)
        playlistRecycler = findViewById(R.id.playlistRecycler)
        cbPlaylistSelectAll = findViewById(R.id.cbPlaylistSelectAll)
        btnDownloadPlaylistSelected = findViewById(R.id.btnDownloadPlaylistSelected)
        btnDownloadPlaylistFull = findViewById(R.id.btnDownloadPlaylistFull)
        formatSpinner = findViewById(R.id.formatSpinner)
        btnDownload = findViewById(R.id.btnDownload)
        progressPrepare = findViewById(R.id.progressPrepare)
        downloadProgressContainer = findViewById(R.id.downloadProgressContainer)
        downloadProgressBar = findViewById(R.id.downloadProgressBar)
        downloadProgressText = findViewById(R.id.downloadProgressText)

        searchRecycler.layoutManager = LinearLayoutManager(this)
        playlistRecycler.layoutManager = LinearLayoutManager(this)

        btnIconUpdate = findViewById(R.id.btnIconUpdate)
        btnIconDonate = findViewById(R.id.btnIconDonate)
        btnIconFolder = findViewById(R.id.btnIconFolder)
        terminalOverlay = findViewById(R.id.terminalOverlay)
        terminalLog = findViewById(R.id.terminalLog)
        terminalScroll = findViewById(R.id.terminalScroll)
        terminalProgress = findViewById(R.id.terminalProgress)
        btnTerminalClose = findViewById(R.id.btnTerminalClose)

        btnIconUpdate.setOnClickListener { startManualDependencyUpdate() }
        btnIconDonate.setOnClickListener {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://buymeacoffee.com/medcodex")
                )
            )
        }
        btnIconFolder.setOnClickListener {
            startActivity(Intent(this, PublicDownloadsActivity::class.java))
        }
        btnTerminalClose.setOnClickListener { terminalOverlay.visibility = View.GONE }

        loadFormats()
        prepareYtdlp()

        btnGo.setOnClickListener { onGo() }
        btnDownload.setOnClickListener { confirmDestinationAndRun { startDownloadSingle() } }
        btnDownloadBatch.setOnClickListener {
            searchAdapter?.let { confirmDestinationAndRun { startBatchDownload(it, btnDownloadBatch) } }
        }
        btnDownloadPlaylistSelected.setOnClickListener {
            playlistAdapter?.let { confirmDestinationAndRun { startBatchDownload(it, btnDownloadPlaylistSelected) } }
        }
        btnDownloadPlaylistFull.setOnClickListener {
            confirmDestinationAndRun { startDownloadPlaylistFull() }
        }
    }

    private fun appendTerminalLine(line: String) {
        runOnUiThread {
            terminalLog.append(line)
            if (!line.endsWith("\n")) {
                terminalLog.append("\n")
            }
            terminalScroll.post {
                terminalScroll.fullScroll(View.FOCUS_DOWN)
            }
        }
    }

    private fun finishTerminalUpdateUi() {
        terminalProgress.visibility = View.GONE
        btnTerminalClose.isEnabled = true
        btnIconUpdate.isEnabled = true
    }

    private fun startManualDependencyUpdate() {
        if (terminalOverlay.visibility == View.VISIBLE) {
            return
        }
        terminalOverlay.visibility = View.VISIBLE
        terminalLog.text = ""
        terminalProgress.visibility = View.VISIBLE
        btnTerminalClose.isEnabled = false
        btnIconUpdate.isEnabled = false

        Thread {
            appendTerminalLine("$ yt-downloader — actualizare dependențe")
            appendTerminalLine("[INFO] Rețea: verifică conexiunea la internet.")
            appendTerminalLine("[STEP] yt-dlp (canal STABLE) — descărcare / înlocuire binar…")

            val app = application as? App
            val initErr = app?.initError
            if (initErr != null) {
                appendTerminalLine("[FAIL] Inițializare aplicație: $initErr")
                appendTerminalLine("[HINT] Reinstalează APK-ul sau eliberează spațiu.")
                runOnUiThread { finishTerminalUpdateUi() }
                return@Thread
            }

            val updateResult = runCatching {
                YoutubeDL.getInstance().updateYoutubeDL(
                    applicationContext,
                    YoutubeDL.UpdateChannel._STABLE
                )
            }
            if (updateResult.isSuccess) {
                appendTerminalLine("[OK] yt-dlp: actualizare finalizată (sau deja la ultima versiune).")
            } else {
                val msg = updateResult.exceptionOrNull()?.message ?: "eroare necunoscută"
                appendTerminalLine("[FAIL] yt-dlp: $msg")
            }

            appendTerminalLine("[STEP] FFmpeg (bibliotecă nativă din APK)…")
            val ffOk = runCatching { FFmpeg.getInstance() }.isSuccess
            if (ffOk) {
                appendTerminalLine("[OK] ffmpeg: modul disponibil (actualizare prin nou APK).")
            } else {
                appendTerminalLine("[WARN] ffmpeg: instanță indisponibilă.")
            }

            appendTerminalLine("[INFO] Alte module (Python încorporat etc.) se livrează cu APK-ul.")
            appendTerminalLine("")
            appendTerminalLine("$ Gata. Poți închide această consolă.")
            runOnUiThread { finishTerminalUpdateUi() }
        }.start()
    }

    private fun loadFormats() {
        formatSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            YtdlpPresets.ALL.map { it.label }
        )
    }

    private fun confirmDestinationAndRun(action: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Unde salvăm fișierele?")
            .setItems(
                arrayOf(
                    "Descărcări publice (folder YTDownloader)",
                    "Alt folder (card, Drive, etc.)"
                )
            ) { _, which ->
                when (which) {
                    0 -> {
                        savePrefs.setDestination(SaveDestination.PUBLIC_DOWNLOADS)
                        action()
                    }
                    1 -> {
                        pendingAfterFolder = Runnable {
                            savePrefs.setDestination(SaveDestination.USER_PICKED_FOLDER)
                            action()
                        }
                        openTreeLauncher.launch(null)
                    }
                }
            }
            .setNegativeButton("Anulează", null)
            .show()
    }

    private fun prepareYtdlp() {
        val app = application as? App
        val initErr = app?.initError
        if (initErr != null) {
            showError("Init yt-dlp/ffmpeg: $initErr\nVerifică că ai instalat ultimul APK și spațiu liber.")
            return
        }
        progressPrepare.visibility = View.VISIBLE
        btnGo.isEnabled = false
        btnDownload.isEnabled = false
        btnDownloadPlaylistSelected.isEnabled = false
        btnDownloadPlaylistFull.isEnabled = false
        Thread {
            val updateResult = runCatching {
                YoutubeDL.getInstance().updateYoutubeDL(
                    applicationContext,
                    YoutubeDL.UpdateChannel._STABLE
                )
            }
            runOnUiThread {
                progressPrepare.visibility = View.GONE
                btnGo.isEnabled = true
                updateResult.exceptionOrNull()?.let { e ->
                    showError("Actualizare yt-dlp: ${e.message ?: e}\nVerifică conexiunea la internet (prima deschidere).")
                }
            }
        }.start()
    }

    private fun isUrl(s: String): Boolean =
        s.startsWith("http://", true) || s.startsWith("https://", true)

    private fun onGo() {
        val raw = inputUrl.text.toString().trim()
        if (raw.isEmpty()) {
            Toast.makeText(this, "Introduceți un URL sau un termen de căutare", Toast.LENGTH_SHORT).show()
            return
        }
        errorText.visibility = View.GONE
        if (isUrl(raw)) {
            runUrlFlow(raw)
        } else {
            runSearchFlow(raw)
        }
    }

    private fun runUrlFlow(raw: String) {
        progressPrepare.visibility = View.VISIBLE
        btnGo.isEnabled = false
        searchPanel.visibility = View.GONE
        searchAdapter = null
        playlistPanel.visibility = View.GONE
        playlistAdapter = null
        btnDownload.visibility = View.VISIBLE
        Thread {
            val r = YtdlpJson.describeUrl(raw)
            runOnUiThread {
                progressPrepare.visibility = View.GONE
                btnGo.isEnabled = true
                if (!r.ok) {
                    showError(YtdlpError.sanitizeForUser(r.error ?: "Nu s-a putut accesa URL-ul."))
                    return@runOnUiThread
                }
                currentVideoUrl = YoutubeUrl.normalize(raw)
                statusText.text = r.description
                statusText.visibility = View.VISIBLE

                val isListable =
                    (r.contentType == "playlist" || r.contentType == "channel") && r.count > 0
                if (isListable) {
                    playlistPanel.visibility = View.GONE
                    urlOptionsRow.visibility = View.GONE
                    btnDownload.visibility = View.GONE
                    btnDownload.isEnabled = false
                    progressPrepare.visibility = View.VISIBLE
                    Thread {
                        val entriesRes = YtdlpJson.fetchPlaylistEntries(raw)
                        runOnUiThread {
                            progressPrepare.visibility = View.GONE
                            entriesRes.exceptionOrNull()?.let { e ->
                                urlOptionsRow.visibility = View.VISIBLE
                                btnDownload.visibility = View.VISIBLE
                                btnDownload.isEnabled = true
                                showError(
                                    YtdlpError.sanitizeForUser(
                                        e.message ?: "Nu s-a putut încărca lista din playlist."
                                    )
                                )
                                return@runOnUiThread
                            }
                            val list = entriesRes.getOrNull().orEmpty()
                            if (list.isEmpty()) {
                                urlOptionsRow.visibility = View.VISIBLE
                                btnDownload.visibility = View.VISIBLE
                                btnDownload.isEnabled = true
                                Toast.makeText(
                                    this@MainActivity,
                                    "Lista nu a putut fi afișată; poți folosi „Descarcă” pentru tot playlist-ul.",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@runOnUiThread
                            }
                            playlistPanel.visibility = View.VISIBLE
                            urlOptionsRow.visibility = View.GONE
                            btnDownload.visibility = View.GONE
                            val adapter = SearchResultsAdapter(list)
                            adapter.onOpenUrl = { url ->
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            }
                            adapter.onSelectionChanged = {
                                updateBatchButton(adapter, btnDownloadPlaylistSelected)
                            }
                            playlistRecycler.adapter = adapter
                            playlistAdapter = adapter
                            cbPlaylistSelectAll.setOnCheckedChangeListener(null)
                            cbPlaylistSelectAll.isChecked = false
                            cbPlaylistSelectAll.setOnCheckedChangeListener { _, checked ->
                                adapter.selectAll(checked)
                            }
                            updateBatchButton(adapter, btnDownloadPlaylistSelected)
                        }
                    }.start()
                } else {
                    playlistPanel.visibility = View.GONE
                    playlistAdapter = null
                    if (r.contentType == "video") {
                        urlOptionsRow.visibility = View.GONE
                    } else {
                        urlOptionsRow.visibility = View.VISIBLE
                    }
                    btnDownload.visibility = View.VISIBLE
                    btnDownload.isEnabled = true
                }
            }
        }.start()
    }

    private fun runSearchFlow(query: String) {
        errorText.visibility = View.GONE
        progressPrepare.visibility = View.VISIBLE
        btnGo.isEnabled = false
        statusText.visibility = View.GONE
        urlOptionsRow.visibility = View.GONE
        playlistPanel.visibility = View.GONE
        playlistAdapter = null
        currentVideoUrl = null
        btnDownload.isEnabled = false
        Thread {
            val res = YtdlpJson.searchYoutube(query)
            runOnUiThread {
                progressPrepare.visibility = View.GONE
                btnGo.isEnabled = true
                res.exceptionOrNull()?.let { e ->
                    showError(YtdlpError.sanitizeForUser(e.message ?: "Căutarea a eșuat"))
                    return@runOnUiThread
                }
                val list = res.getOrNull() ?: emptyList()
                if (list.isEmpty()) {
                    showError("Niciun rezultat.")
                    return@runOnUiThread
                }
                searchPanel.visibility = View.VISIBLE
                btnDownload.visibility = View.GONE
                val adapter = SearchResultsAdapter(list)
                adapter.onOpenUrl = { url ->
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
                adapter.onSelectionChanged = { updateBatchButton(adapter, btnDownloadBatch) }
                searchRecycler.adapter = adapter
                searchAdapter = adapter
                cbSelectAll.setOnCheckedChangeListener(null)
                cbSelectAll.isChecked = false
                cbSelectAll.setOnCheckedChangeListener { _, checked ->
                    adapter.selectAll(checked)
                }
                updateBatchButton(adapter, btnDownloadBatch)
            }
        }.start()
    }

    private fun updateBatchButton(adapter: SearchResultsAdapter, button: Button) {
        val n = adapter.selectedCount()
        button.text = "Descarcă selectate ($n)"
        button.isEnabled = n > 0
    }

    private fun showError(msg: String) {
        errorText.text = msg
        errorText.visibility = View.VISIBLE
        statusText.visibility = View.GONE
        urlOptionsRow.visibility = View.GONE
        playlistPanel.visibility = View.GONE
        playlistAdapter = null
        btnDownload.isEnabled = false
    }

    private fun showDownloadProgressUi() {
        downloadProgressContainer.visibility = View.VISIBLE
        downloadProgressBar.progress = 0
        downloadProgressText.text = "0%"
    }

    private fun hideDownloadProgressUi() {
        downloadProgressContainer.visibility = View.GONE
    }

    private fun formatEtaLine(etaSeconds: Long): String {
        if (etaSeconds <= 0L) return ""
        val m = etaSeconds / 60
        val s = etaSeconds % 60
        return if (m > 0) " · ~${m}m ${s}s" else " · ~${s}s"
    }

    private fun startDownloadSingle() {
        val url = currentVideoUrl ?: return
        val formatIndex = formatSpinner.selectedItemPosition
        if (formatIndex !in YtdlpPresets.ALL.indices) return
        val noPlaylist = switchNoPlaylist.isChecked
        progressPrepare.visibility = View.GONE
        showDownloadProgressUi()
        btnDownload.isEnabled = false
        btnGo.isEnabled = false
        Thread {
            val outputDir = File(getExternalFilesDir(null), "downloads").apply { mkdirs() }
            val result = YtdlpDownload.runDownload(
                url, outputDir, formatIndex, noPlaylist,
                onProgress = { progress, eta, line ->
                    runOnUiThread {
                        val pct = (progress * 100f).toInt().coerceIn(0, 100)
                        downloadProgressBar.progress = pct
                        val tail = line.trim().take(72)
                        downloadProgressText.text = buildString {
                            append("$pct%")
                            append(formatEtaLine(eta))
                            if (tail.isNotEmpty()) {
                                append("\n")
                                append(tail)
                            }
                        }
                    }
                }
            )
            val exported = runExportForPrefs(result.getOrNull().orEmpty())
            runOnUiThread {
                hideDownloadProgressUi()
                btnDownload.isEnabled = true
                btnGo.isEnabled = true
                result.exceptionOrNull()?.let {
                    showError(
                        "Descărcarea locală a eșuat:\n" +
                            YtdlpError.sanitizeForUser(it.message ?: "eroare")
                    )
                    return@runOnUiThread
                }
                val files = result.getOrNull().orEmpty()
                if (files.isEmpty()) {
                    showError("Nu s-au găsit fișiere după descărcare.")
                    return@runOnUiThread
                }
                toastExportResult(files, exported)
            }
        }.start()
    }

    private fun startDownloadPlaylistFull() {
        val url = currentVideoUrl ?: return
        val formatIndex = formatSpinner.selectedItemPosition
        if (formatIndex !in YtdlpPresets.ALL.indices) return
        progressPrepare.visibility = View.GONE
        showDownloadProgressUi()
        btnDownloadPlaylistFull.isEnabled = false
        btnDownloadPlaylistSelected.isEnabled = false
        btnGo.isEnabled = false
        Thread {
            val outputDir = File(getExternalFilesDir(null), "downloads").apply { mkdirs() }
            val result = YtdlpDownload.runDownload(
                url, outputDir, formatIndex, noPlaylist = false,
                onProgress = { progress, eta, line ->
                    runOnUiThread {
                        val pct = (progress * 100f).toInt().coerceIn(0, 100)
                        downloadProgressBar.progress = pct
                        val tail = line.trim().take(72)
                        downloadProgressText.text = buildString {
                            append("Playlist · $pct%")
                            append(formatEtaLine(eta))
                            if (tail.isNotEmpty()) {
                                append("\n")
                                append(tail)
                            }
                        }
                    }
                }
            )
            val exported = runExportForPrefs(result.getOrNull().orEmpty())
            runOnUiThread {
                hideDownloadProgressUi()
                btnDownloadPlaylistFull.isEnabled = true
                btnDownloadPlaylistSelected.isEnabled =
                    (playlistAdapter?.selectedCount() ?: 0) > 0
                btnGo.isEnabled = true
                result.exceptionOrNull()?.let {
                    showError(
                        "Descărcarea a eșuat:\n" +
                            YtdlpError.sanitizeForUser(it.message ?: "eroare")
                    )
                    return@runOnUiThread
                }
                val files = result.getOrNull().orEmpty()
                if (files.isEmpty()) {
                    showError("Nu s-au găsit fișiere după descărcare.")
                    return@runOnUiThread
                }
                toastExportResult(files, exported)
            }
        }.start()
    }

    private fun startBatchDownload(adapter: SearchResultsAdapter, batchButton: Button) {
        val urls = adapter.getSelectedUrls()
        if (urls.isEmpty()) return
        val formatIndex = formatSpinner.selectedItemPosition
        if (formatIndex !in YtdlpPresets.ALL.indices) return
        val total = urls.size
        progressPrepare.visibility = View.GONE
        showDownloadProgressUi()
        batchButton.isEnabled = false
        btnGo.isEnabled = false
        Thread {
            val outputDir = File(getExternalFilesDir(null), "downloads").apply { mkdirs() }
            val allFiles = mutableListOf<File>()
            val errors = mutableListOf<String>()
            urls.forEachIndexed { index, url ->
                val result = YtdlpDownload.runDownload(
                    url, outputDir, formatIndex, noPlaylist = true,
                    onProgress = { progress, eta, line ->
                        runOnUiThread {
                            val pct = (progress * 100f).toInt().coerceIn(0, 100)
                            downloadProgressBar.progress = pct
                            val tail = line.trim().take(56)
                            downloadProgressText.text = buildString {
                                append("Clip ${index + 1}/$total · $pct%")
                                append(formatEtaLine(eta))
                                if (tail.isNotEmpty()) {
                                    append("\n")
                                    append(tail)
                                }
                            }
                        }
                    }
                )
                result.onSuccess { allFiles.addAll(it) }
                result.onFailure { errors.add(it.message ?: "eroare") }
            }
            val exported = runExportForPrefs(allFiles)
            runOnUiThread {
                hideDownloadProgressUi()
                batchButton.isEnabled = adapter.selectedCount() > 0
                btnGo.isEnabled = true
                if (allFiles.isEmpty()) {
                    showError(
                        YtdlpError.sanitizeForUser(errors.firstOrNull() ?: "Nicio descărcare reușită.")
                    )
                    return@runOnUiThread
                }
                errorText.visibility = View.GONE
                val dir = allFiles.first().parentFile?.absolutePath ?: ""
                val errHint = if (errors.isNotEmpty()) {
                    "\nUnele: ${YtdlpError.sanitizeForUser(errors.first())}"
                } else {
                    ""
                }
                Toast.makeText(
                    this,
                    "Gata: ${allFiles.size} fișier(e).\nSalvat în app:\n$dir\nExport suplimentar: $exported/${allFiles.size}.$errHint",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun runExportForPrefs(files: List<File>): Int {
        if (files.isEmpty()) return 0
        return when (savePrefs.getDestination()) {
            SaveDestination.PRIVATE_APP_ONLY -> 0
            SaveDestination.PUBLIC_DOWNLOADS -> {
                var ok = 0
                for (f in files) {
                    if (runCatching { DownloadExporter.copyToPublicDownloads(this, f) }.getOrNull() != null) {
                        ok++
                    }
                }
                ok
            }
            SaveDestination.USER_PICKED_FOLDER -> {
                val uriStr = savePrefs.getTreeUriString() ?: return fallbackPublicExport(files)
                val uri = Uri.parse(uriStr)
                var ok = 0
                for (f in files) {
                    if (UserFolderExporter.copyFileToTree(this, uri, f)) ok++
                }
                if (ok == 0 && files.isNotEmpty()) fallbackPublicExport(files) else ok
            }
        }
    }

    private fun fallbackPublicExport(files: List<File>): Int {
        var ok = 0
        for (f in files) {
            if (runCatching { DownloadExporter.copyToPublicDownloads(this, f) }.getOrNull() != null) ok++
        }
        return ok
    }

    private fun toastExportResult(files: List<File>, exportedCount: Int) {
        val names = files.joinToString(", ") { it.name }
        val appDir = files.first().parentFile?.absolutePath ?: ""
        val mode = savePrefs.getDestination()
        val exportLine = when (mode) {
            SaveDestination.PRIVATE_APP_ONLY ->
                "Nu s-a copiat în afara aplicației (ai ales doar memoria privată)."
            SaveDestination.USER_PICKED_FOLDER ->
                when {
                    exportedCount >= files.size -> "Copiat și în folderul ales."
                    exportedCount > 0 -> "Parțial în folderul ales ($exportedCount/${files.size}); restul doar în calea de mai sus."
                    else -> "Nu s-a putut scrie în folderul ales; fișierele sunt în calea de mai sus."
                }
            SaveDestination.PUBLIC_DOWNLOADS ->
                when {
                    exportedCount >= files.size && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                        "Copiat și în Descărcări → YTDownloader."
                    exportedCount >= files.size ->
                        "Copiat în Descărcări publice."
                    else ->
                        "Export suplimentar: $exportedCount/${files.size}."
                }
        }
        Toast.makeText(
            this,
            "Gata: $names\n\nSalvare locală (sursă):\n$appDir\n\n$exportLine",
            Toast.LENGTH_LONG
        ).show()
    }
}
